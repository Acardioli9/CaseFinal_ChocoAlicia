import React from 'react'
import './App.css'

import { Routes, Route } from 'react-router-dom'

import Index from './components/pages/Index/Index'
import QuemSomos from './components/pages/QuemSomos'
import NossoTime from './components/pages/NossoTime'
import Presentes from './components/pages/Presentes/Presentes'
import Contato from './components/pages/Contato'

import LoginAdmin from './components/Admin/LoginAdmin'
import Admin from './components/Admin/Admin'
import Produtos from './components/Admin/Produtos'
import LinhasComerciais from './components/Admin/LinhasComerciais'
import AdcProduto from './components/Admin/AdcProduto'
import AdcLinha from './components/Admin/AdcLinha'
import EditarProduto from './components/Admin/EditarProduto'
import EditarLinha from './components/Admin/EditarLinha'

import ImpulseCompany from './components/ImpulseCompany/ImpulseCompany'


function App() {
  
  return (
    <>
      <Routes>
        <Route path='/' element={<Index />} />
        <Route path='/QuemSomos' element={<QuemSomos />} />
        <Route path='/NossoTime' element={<NossoTime />} />
        <Route path='/Presentes' element={<Presentes />} />
        <Route path='/Contato' element={<Contato />} />np

        <Route path='/LoginAdmin' element={<LoginAdmin />} />
        <Route path='/Admin' element={<Admin />} />
        <Route path='/Produtos' element={<Produtos />} />
        <Route path='/LinhasComerciais' element={<LinhasComerciais />} />
        <Route path='/AdicionarProduto' element={<AdcProduto />} />
        <Route path='/AdicionarLinha' element={<AdcLinha/>} />
        <Route path='/EditarProduto' element={<EditarProduto />} />
        <Route path='/EditarLinha' element={<EditarLinha />} />
        
        <Route path='/ImpulseCompany' element={<ImpulseCompany />} />
      </Routes>
    </>
  )
}


export default App

